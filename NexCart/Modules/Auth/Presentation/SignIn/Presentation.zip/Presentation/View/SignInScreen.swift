//
//  SignInScreen.swift
//  NexCart
//
//  Created by Mohamed Magdy on 28/06/2026.
//

import SwiftUI

struct SignInScreen: View {
    @StateObject var signViewModel: SignInViweModel = DIContainer.shared.container.resolve(SignInViweModel.self)!
    
    var body: some View {
     
        switch signViewModel.screenState{
        case.idel:
            SignInScreenIdelState()
        case.loading:
            SignInScreenLoadingState()
        case.success:
            SignInScreenSuccessState()
        }
        
    }
}


struct SignInScreenIdelState: View{
    // wanna here the normal sign in screen
    var body: some View{
        Text("")
    }
}

struct SignInScreenLoadingState: View{
    // here with just loading
    var body: some View{
        Text("")
    }
}

struct SignInScreenSuccessState: View{
    // here brand new screen with animation and welcom message them nav to HomeScree()
    var body: some View{
        Text("")
    }
}



struct SignInScreen_Previews: PreviewProvider {
    static var previews: some View {
        SignInScreen(signViewModel: <#T##SignInViweModel#>)
    }
}
