//
//  SignUpScreen.swift
//  NexCart
//
//  Created by Mohamed Magdy on 28/06/2026.
//

import SwiftUI

struct SignUpScreen: View {
    var body: some View {
        ZStack {
            Color.authBackground.ignoresSafeArea()

            switch viewModel.screenState {
            case .idle:
                SignInIdleState(viewModel: viewModel)
            case .loading:
                SignInLoadingState()
            case .success:
                SignInSuccessState(vm: viewModel)
            }
        }
        .alert(item: $viewModel.alert) { alert in
            Alert(
                title: Text(alert.title),
                message: Text(alert.description ),
                dismissButton: .default(Text("OK"))
            )
        }
    }
}

struct SignUpScreen_Previews: PreviewProvider {
    static var previews: some View {
        SignUpScreen()
    }
}
