//
//  SignUpViewModel.swift
//  NexCart
//
//  Created by Mohamed Magdy on 28/06/2026.
//

import Foundation

enum ScreenState {
    case idle
    case loading
    case success
    case error(error: String)
}


class SignUpViewModel: ObservableObject{
    @Published var screenState: ScreenState = .idle
    @Published var alert: AlertModel?
    
    
    //UseCases
    private var signUpUseCase: CreatNewAccountUseCaseProtocol
    
    init(signUpUseCase: CreatNewAccountUseCaseProtocol) {
        self.signUpUseCase = signUpUseCase
    }
    
    func creatNewAccount(signUpCredentials: SignUpCredentials){
        screenState = .loading
        Task{
            do{
                var userEntity = try await signUpUseCase.excute(signUpCredentials: signUpCredentials)
                screenState = .success
            }catch let error as AuthError{
                alert = AlertModel(title: "Error", description: error.errorDescription)
                screenState = .idle
            }
            
        }
    }
}
